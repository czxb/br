library(ggplot2)
library(ggimage)
library(tibble)
library(ggchicklet)
library(magick)
library(export)
cat <- tribble(
  ~id, ~downloads, ~img, ~color,
  1, 10172, "1.png", "#DF3C2D",
  2, 8563, "2.png", "#333333",
  3, 7834, "3.png", "#CC5919",
  4, 7705, "4.png", "#789DD3",
  5, 7167, "5.png", "#FD9B31",
  6, 6507, "6.png", "#6E3015",
  7, 6264, "7.png", "#F4A2B0",
  8, 5551, "8.png", "#FEE542",
  9, 4964, "9.png", "#DE3C2C",
  10, 3930, "10.png", "#F6BD97",
  11, 3763, "11.png", "#524A52",
  12, 3357, "12.png", "#FECC55",
  13, 3153, "13.png", "#BCAD84",
  14, 2617, "14.png", "#21CD95",
  15, 2546, "15.png", "#635A5A",
  16, 2358, "16.png", "#7D7EDF"
)
cat %>%
  ggplot() +
  geom_chicklet(aes(x = factor(id), y = downloads,
                    fill = I(color), color = I(color))) +
  geom_image(aes(x = factor(id), y = -800,
                 image = img), size = 0.07) +
  theme_ipsum(base_family = "MLingWaiMedium-SC") + 
  theme(legend.position = "none",
        axis.title.y = element_blank(),
        axis.text.y = element_blank(),
        panel.grid.major.y = element_blank(),
        panel.grid.minor.y = element_blank(),
        panel.background = element_rect(fill = "#F3F3F3", color = "#F3F3F3"),
        panel.border = element_blank(),
        plot.background = element_rect(fill = "#F3F3F3"),
        axis.title.x = element_blank()) + 
  coord_flip() + 
  labs(title = "你最常用哪个表情？") + 
  theme(plot.title = element_text(size = 28))
ggsave(filename = "mycat.png")

mycat <- image_read("mycat.png")
catgif <- image_read("cat.gif")
frames <- image_composite(mycat, catgif, offset = "+600+200")
animation <- image_animate(frames)
image_write(animation, "catstat.gif")
image_write_video(animation, "catstat.mp4")
